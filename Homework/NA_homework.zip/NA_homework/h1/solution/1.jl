x=0;
f=sin(x)
x=pi;
f=(sin(1e4*x))/x
