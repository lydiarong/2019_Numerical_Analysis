var searchData=
[
  ['fingerangles',['FingerAngles',['../classkinova_1_1_finger_angles.html',1,'kinova']]]
];
